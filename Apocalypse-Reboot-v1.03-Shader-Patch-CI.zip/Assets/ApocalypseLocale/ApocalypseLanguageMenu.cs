using AC;
using UnityEngine;
using UnityEngine.SceneManagement;
using SceneManager = UnityEngine.SceneManagement.SceneManager;

public sealed class ApocalypseLanguageMenu : MonoBehaviour
{
    private const string LanguageKey = "Language";
    private const int English = 0;
    private const int Russian = 4;
    private const int Ukrainian = 5;

    private bool inMainMenu;
    private bool expanded;
    private bool syncLanguage;
    private Font menuFont;
    private GUIStyle buttonStyle;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void Install()
    {
        if (Application.platform != RuntimePlatform.IPhonePlayer)
            return;

        var language = PlayerPrefs.GetInt(LanguageKey, English);
        if (!PlayerPrefs.HasKey(LanguageKey) || language < English || language > Ukrainian)
            PlayerPrefs.SetInt(LanguageKey, English);

        var root = new GameObject("Apocalypse Language Menu");
        DontDestroyOnLoad(root);
        root.AddComponent<ApocalypseLanguageMenu>();
    }

    private void Awake()
    {
        menuFont = Resources.Load<Font>("ApocalypseLocale/LiberationSans");
    }

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
        EventManager.OnChangeLanguage += OnLanguageChanged;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
        EventManager.OnChangeLanguage -= OnLanguageChanged;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (mode != LoadSceneMode.Single)
            return;
        inMainMenu = scene.name == "MenuDemo";
        expanded = false;
        syncLanguage = true;

        foreach (var root in scene.GetRootGameObjects())
        foreach (var selector in root.GetComponentsInChildren<Lenguageidk>(true))
        {
            if (selector.languages == null || selector.languages.Count != Russian)
                continue;
            selector.languages.Add(new Lenguageidk.language { name = "Русский" });
            selector.languages.Add(new Lenguageidk.language { name = "Українська" });
        }
    }

    private void LateUpdate()
    {
        if (!syncLanguage || Options.optionsData == null)
            return;
        int language = PlayerPrefs.GetInt(LanguageKey, English);
        var runtime = KickStarter.runtimeLanguages;
        if (runtime == null || language < English || runtime.Languages.Count <= language || KickStarter.eventManager == null)
            return;
        syncLanguage = false;
        if (Options.GetLanguage() != language)
            Options.SetLanguage(language);
    }

    private void OnLanguageChanged(int language)
    {
        if (language < English || language > Ukrainian || PlayerPrefs.GetInt(LanguageKey, English) == language)
            return;
        PlayerPrefs.SetInt(LanguageKey, language);
        PlayerPrefs.Save();

        if (!inMainMenu)
            return;
        foreach (var label in FindObjectsOfType<TranslateText>())
        {
            if (!label.isActiveAndEnabled)
                continue;
            label.enabled = false;
            label.enabled = true;
        }
    }

    private void SelectLanguage(int language)
    {
        OnLanguageChanged(language);
        syncLanguage = true;
        expanded = false;
    }

    private void OnGUI()
    {
        if (!inMainMenu)
            return;
        if (buttonStyle == null)
            buttonStyle = new GUIStyle(GUI.skin.button) { font = menuFont, alignment = TextAnchor.MiddleCenter };

        var safeArea = Screen.safeArea;
        float height = Mathf.Clamp(safeArea.height * 0.075f, 38f, 92f);
        float gap = height * 0.18f;
        float width = height * 3.85f;
        var bounds = new Rect(safeArea.xMax - width - gap, Screen.height - safeArea.yMax + gap, width, height);
        buttonStyle.fontSize = Mathf.RoundToInt(height * 0.43f);

        int language = PlayerPrefs.GetInt(LanguageKey, English);
        string caption = language == Russian ? "Язык" : language == Ukrainian ? "Мова" : "Language";
        int originalDepth = GUI.depth;
        GUI.depth = -100;
        if (GUI.Button(bounds, caption, buttonStyle))
            expanded = !expanded;
        if (expanded)
        {
            bounds.y += height + gap;
            if (GUI.Button(bounds, "English", buttonStyle))
                SelectLanguage(English);
            bounds.y += height + gap;
            if (expanded && GUI.Button(bounds, "Русский", buttonStyle))
                SelectLanguage(Russian);
            bounds.y += height + gap;
            if (expanded && GUI.Button(bounds, "Українська", buttonStyle))
                SelectLanguage(Ukrainian);
        }
        GUI.depth = originalDepth;
    }
}
