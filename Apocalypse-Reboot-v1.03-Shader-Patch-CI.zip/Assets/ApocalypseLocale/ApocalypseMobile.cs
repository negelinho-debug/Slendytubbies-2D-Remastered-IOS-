using System.Collections.Generic;
using AC;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using SceneManager = UnityEngine.SceneManagement.SceneManager;
using Button = UnityEngine.UI.Button;

[DefaultExecutionOrder(-300)]
public sealed class ApocalypseMobile : MonoBehaviour
{
    private const string GuideTitle = "How to play";
    private const string MainMenu = "MenuDemo";
    private const string MainPlayPath = "Canvas/MenuNormal/ButtonsMain/Menuelements/Image/Text";

    private PlayerInput gameInput;
    private Menu guide;
    private Button originalPlay;
    private Font font;
    private GUIStyle largeButton;
    private GUIStyle body;
    private GUIStyle title;
    private Texture2D ring;
    private Texture2D knob;
    private string sceneName;
    private bool showInventory;
    private bool subtitlesSet;
    private bool menuReady;
    private bool canMove;
    private bool qteActive;
    private Vector2 inventoryScroll;
    private Vector2 choiceScroll;

    private int moveFinger = -1;
    private int runFinger = -1;
    private int lookFinger = -1;
    private Vector2 moveOrigin;
    private Vector2 movement;
    private Vector2 lookOrigin;
    private Vector2 aimDelta;
    private Vector2 pointerPosition;
    private float lookStarted;
    private bool lookWasDragged;
    private bool interactPressed;
    private bool flashPressed;
    private bool pausePressed;
    private bool qtePressed;
    private int advanceSpeechFrame = -2;

    private Speech speech;
    private Conversation conversation;
    private Rect safe;
    private Rect moveRect;
    private Rect runRect;
    private Rect actionRect;
    private Rect inventoryRect;
    private Rect pauseRect;
    private Rect flashRect;
    private float size;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void Install()
    {
        if (Application.platform == RuntimePlatform.IPhonePlayer)
        {
            var root = new GameObject("Apocalypse iOS controls");
            DontDestroyOnLoad(root);
            root.AddComponent<ApocalypseMobile>();
        }
    }

    private void Awake()
    {
        font = Resources.Load<Font>("ApocalypseLocale/LiberationSans");
        ring = MakeCircle(new Color(0.15f, 0.20f, 0.23f, 0.65f));
        knob = MakeCircle(new Color(0.85f, 0.92f, 0.92f, 0.72f));
        SceneManager.sceneLoaded += OnSceneLoaded;
        AC.EventManager.OnMenuTurnOn += OnMenuTurnOn;
    }

    private void OnDestroy()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
        AC.EventManager.OnMenuTurnOn -= OnMenuTurnOn;
        Destroy(ring);
        Destroy(knob);
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (mode != LoadSceneMode.Single)
            return;

        sceneName = scene.name;
        gameInput = null;
        guide = null;
        originalPlay = null;
        menuReady = false;
        showInventory = false;
        inventoryScroll = Vector2.zero;
        choiceScroll = Vector2.zero;
        pointerPosition = new Vector2(Screen.width / 2f, Screen.height / 2f);
        ResetTouches();
        advanceSpeechFrame = -2;

        foreach (var root in scene.GetRootGameObjects())
        {
            RepairFonts(root);
            if (sceneName != MainMenu)
                continue;

            var original = root.transform.Find(MainPlayPath);
            if (original == null)
                continue;

            originalPlay = original.GetComponent<Button>();
            if (originalPlay != null)
            {
                var graphic = originalPlay.targetGraphic;
                if (graphic != null)
                {
                    graphic.raycastTarget = false;
                    graphic.enabled = false;
                }
                originalPlay.enabled = false;
            }
        }
    }

    private void RepairFonts(GameObject root)
    {
        if (font == null)
            return;

        foreach (var text in root.GetComponentsInChildren<Text>(true))
        {
            text.font = font;
            text.material = null;
        }
    }

    private void OnMenuTurnOn(Menu menu, bool isInstant)
    {
        if (menu.title == GuideTitle)
            guide = menu;

        var canvas = menu.RuntimeCanvas;
        if (canvas == null)
            return;

        // Preserve the original menu state and its ActionLists.
        if (menu.title == GuideTitle || menu.appearType == AppearType.WhenSpeechPlays ||
            menu.title == "Conversation" || menu.title == "Inventory")
        {
            canvas.enabled = false;
            var raycaster = canvas.GetComponent<GraphicRaycaster>();
            if (raycaster != null)
                raycaster.enabled = false;
        }
        else
        {
            RepairFonts(canvas.gameObject);
        }
    }

    private void Update()
    {
        Layout();
        interactPressed = flashPressed = pausePressed = qtePressed = false;
        aimDelta = Vector2.zero;
        speech = null;
        if (KickStarter.dialog != null)
            speech = KickStarter.dialog.GetLatestSpeech();

        var currentInput = KickStarter.playerInput;
        if (gameInput != currentInput)
        {
            gameInput = currentInput;
            if (gameInput != null)
            {
                gameInput.InputGetAxisDelegate = GetAxis;
                gameInput.InputGetButtonDelegate = GetButton;
                gameInput.InputGetButtonDownDelegate = GetButtonDown;
                gameInput.InputGetMouseButtonDownDelegate = GetMouseButtonDown;
                gameInput.InputGetMouseButtonDelegate = GetMouseButtonDown;
                gameInput.InputMousePositionDelegate = GetPointerPosition;
                gameInput.InputGetFreeAimDelegate = GetAim;
                gameInput.InputGetButtonUpDelegate = GetButtonUp;
            }
        }

        var state = KickStarter.stateHandler;
        conversation = gameInput == null ? null : gameInput.activeConversation;
        canMove = state != null && state.IsInGameplay() && KickStarter.player != null &&
            sceneName != MainMenu && sceneName != "COMPANYNAME" &&
            (guide == null || !guide.IsOn()) && conversation == null;

        if (!subtitlesSet && Options.optionsData != null && KickStarter.eventManager != null)
        {
            if (!Options.AreSubtitlesOn())
                Options.SetSubtitles(true);
            subtitlesSet = true;
        }

        if (!menuReady && state != null && state.IsInGameplay() && sceneName != MainMenu)
        {
            var menus = PlayerMenus.GetMenus();
            if (menus != null && menus.Count > 0)
            {
                foreach (var menu in menus)
                    if (menu.IsOn())
                        OnMenuTurnOn(menu, true);
                menuReady = true;
            }
        }

        qteActive = KickStarter.playerQTE != null && KickStarter.playerQTE.QTEIsActive();
        if (!canMove || showInventory)
            ResetTouches();

        for (int index = 0; index < Input.touchCount; index++)
        {
            var touch = Input.GetTouch(index);
            var point = new Vector2(touch.position.x, Screen.height - touch.position.y);
            if (qteActive && touch.phase == TouchPhase.Began && actionRect.Contains(point))
                qtePressed = true;
            if (canMove && !showInventory && !qteActive)
                HandleTouch(touch, point);
        }
    }

    private void HandleTouch(Touch touch, Vector2 point)
    {
        int finger = touch.fingerId;
        switch (touch.phase)
        {
            case TouchPhase.Began:
                if (inventoryRect.Contains(point))
                {
                    inventoryScroll = Vector2.zero;
                    showInventory = true;
                    ResetTouches();
                }
                else if (pauseRect.Contains(point))
                    pausePressed = true;
                else if (flashRect.Contains(point))
                    flashPressed = true;
                else if (actionRect.Contains(point))
                {
                    pointerPosition = new Vector2(safe.center.x, Screen.height - safe.center.y);
                    interactPressed = true;
                }
                else if (runRect.Contains(point) && runFinger < 0)
                    runFinger = finger;
                else if (moveRect.Contains(point) && moveFinger < 0)
                {
                    moveFinger = finger;
                    moveOrigin = point;
                }
                else if (safe.Contains(point) && lookFinger < 0)
                {
                    lookFinger = finger;
                    lookOrigin = point;
                    lookStarted = Time.unscaledTime;
                    lookWasDragged = false;
                    pointerPosition = touch.position;
                }
                break;

            case TouchPhase.Moved:
            case TouchPhase.Stationary:
                if (finger == moveFinger)
                {
                    var delta = point - moveOrigin;
                    movement = Vector2.ClampMagnitude(new Vector2(delta.x, -delta.y) / (size * 0.7f), 1f);
                    if (movement.sqrMagnitude < 0.015f)
                        movement = Vector2.zero;
                }
                else if (finger == lookFinger)
                {
                    lookWasDragged |= (point - lookOrigin).sqrMagnitude > size * size * 0.028f;
                    if (lookWasDragged && lookOrigin.x >= safe.center.x)
                        aimDelta = touch.deltaPosition * (19f / Mathf.Max(1f, safe.height));
                }
                break;

            case TouchPhase.Ended:
            case TouchPhase.Canceled:
                if (finger == moveFinger)
                {
                    moveFinger = -1;
                    movement = Vector2.zero;
                }
                if (finger == runFinger)
                    runFinger = -1;
                if (finger == lookFinger)
                {
                    lookFinger = -1;
                    if (touch.phase == TouchPhase.Ended && !lookWasDragged &&
                        Time.unscaledTime - lookStarted < 0.3f)
                    {
                        pointerPosition = touch.position;
                        interactPressed = true;
                    }
                }
                break;
        }
    }

    private void ResetTouches()
    {
        moveFinger = runFinger = lookFinger = -1;
        movement = aimDelta = Vector2.zero;
    }

    private bool GetMouseButtonDown(int button)
    {
        return button == 0 && interactPressed;
    }

    private Vector2 GetPointerPosition(bool locked)
    {
        if (locked && !interactPressed)
            return new Vector2(safe.center.x, Screen.height - safe.center.y);
        return pointerPosition;
    }

    private Vector2 GetAim(bool locked)
    {
        return aimDelta;
    }

    private float GetAxis(string input)
    {
        switch (input)
        {
            case "Horizontal": return movement.x;
            case "Vertical": return movement.y;
            case "CursorHorizontal":
            case "Mouse X": return aimDelta.x;
            case "CursorVertical":
            case "Mouse Y": return aimDelta.y;
            case "Run": return runFinger >= 0 ? 1 : 0;
            case "QTE Q": return qtePressed ? 1 : 0;
            default: return 0;
        }
    }

    private bool GetButton(string input)
    {
        return (input == "Run" && runFinger >= 0) ||
            ((input == "InteractionA" || input == "Fire1") && interactPressed) ||
            (input == "QTE Q" && qtePressed);
    }

    private bool GetButtonDown(string input)
    {
        switch (input)
        {
            case "Menu": return pausePressed;
            case "FlashHotspots": return flashPressed;
            case "InteractionA":
            case "Fire1": return interactPressed;
            case "QTE Q": return qtePressed;
            case "SkipSpeech":
                bool pressed = Time.frameCount <= advanceSpeechFrame + 1;
                advanceSpeechFrame = -2;
                return pressed;
            default: return false;
        }
    }

    private bool GetButtonUp(string input)
    {
        return false;
    }

    private void Layout()
    {
        Rect rect = Screen.safeArea;
        safe = new Rect(rect.x, Screen.height - rect.yMax, rect.width, rect.height);
        size = Mathf.Clamp(safe.height * 0.095f, 39f, 115f);
        moveRect = new Rect(safe.x + size * 0.4f, safe.yMax - size * 2.65f, size * 2.2f, size * 2.2f);
        actionRect = new Rect(safe.xMax - size * 2.2f, safe.yMax - size * 1.6f, size * 1.8f, size);
        runRect = new Rect(actionRect.x, actionRect.y - size * 1.18f, actionRect.width, size);
        pauseRect = new Rect(safe.xMax - size * 1.65f, safe.y + size * 0.25f, size * 1.4f, size * 0.82f);
        inventoryRect = new Rect(pauseRect.x - size * 2.8f, pauseRect.y, size * 2.62f, pauseRect.height);
        flashRect = new Rect(safe.x + size * 0.25f, pauseRect.y, size * 2.5f, pauseRect.height);
    }

    private void OnGUI()
    {
        if (size <= 0f)
            return;

        PrepareStyles();
        int depth = GUI.depth;
        GUI.depth = -90;

        if (sceneName == MainMenu)
            DrawMainMenu();
        else if (guide != null && guide.IsOn())
            DrawGuide();
        else
        {
            if (speech != null && speech.isAlive && !string.IsNullOrWhiteSpace(speech.displayText))
                DrawSpeech();

            if (conversation != null)
                DrawChoices();
            else if (showInventory)
                DrawInventory();
            else if (qteActive)
                DrawButtonMarker(actionRect, Translate("Press", "Нажми", "Натисни"), qtePressed);
            else if (canMove)
                DrawControls();
        }

        GUI.depth = depth;
    }

    private void PrepareStyles()
    {
        if (largeButton == null)
        {
            largeButton = new GUIStyle(GUI.skin.button) {
                font = font, wordWrap = true, alignment = TextAnchor.MiddleCenter
            };
            body = new GUIStyle(GUI.skin.label) {
                font = font, wordWrap = true, alignment = TextAnchor.MiddleCenter
            };
            body.normal.textColor = Color.white;
            title = new GUIStyle(body) { fontStyle = FontStyle.Bold };
        }

        largeButton.fontSize = Mathf.RoundToInt(size * 0.29f);
        body.fontSize = Mathf.RoundToInt(size * 0.35f);
        title.fontSize = Mathf.RoundToInt(size * 0.46f);
    }

    private void DrawMainMenu()
    {
        if (originalPlay == null || !originalPlay.gameObject.activeInHierarchy)
            return;

        var button = new Rect(safe.center.x - size * 2f, safe.yMax - size * 1.9f, size * 4f, size);
        if (GUI.Button(button, Translate("Play", "Играть", "Грати"), largeButton))
            originalPlay.onClick.Invoke();
    }

    private void DrawGuide()
    {
        var panel = CenterPanel(size * 8.6f, size * 5.35f);
        DrawBackground(panel);
        GUI.Label(new Rect(panel.x, panel.y + size * 0.23f, panel.width, size * 0.8f),
            Translate("Touch controls", "Управление", "Керування"), title);
        string help = Translate(
            "Left stick — move\nSwipe the right side — look\nHold Run to sprint\nTap an object or press Use to interact\nInventory holds the items you pick up",
            "Левый джойстик — ходьба\nСвайп справа — поворот камеры\nУдерживай «Бег», чтобы бежать\nНажми на предмет или кнопку «Действие»\nПодобранные предметы — в инвентаре",
            "Лівий джойстик — рух\nСвайп праворуч — поворот камери\nУтримуй «Біг», щоб бігти\nТоркнися предмета або кнопки «Дія»\nПідібрані предмети — в інвентарі");
        GUI.Label(new Rect(panel.x + size * 0.3f, panel.y + size, panel.width - size * 0.6f, size * 3.03f), help, body);
        var button = new Rect(panel.center.x - size * 2f, panel.yMax - size * 1.15f, size * 4f, size * 0.88f);
        if (GUI.Button(button, Translate("Continue", "Продолжить", "Продовжити"), largeButton))
            guide.TurnOff(false);
    }

    private void DrawSpeech()
    {
        string speaker = speech.GetSpeaker(Options.GetLanguage());
        string line = string.IsNullOrEmpty(speaker) ? speech.displayText : speaker + " — " + speech.displayText;
        float width = Mathf.Min(safe.width * 0.78f, size * 12f);
        float height = Mathf.Clamp(body.CalcHeight(new GUIContent(line), width - size * 0.48f),
            size * 0.55f, size * 3f);
        float y = conversation != null || showInventory ? safe.y + size * 0.1f :
            safe.yMax - size * (canMove ? 3.15f : 1.45f) - height;
        var panel = new Rect(safe.center.x - width / 2f, y, width, height + size * 0.28f);
        DrawBackground(panel);
        GUI.Label(new Rect(panel.x + size * 0.24f, panel.y, width - size * 0.48f, panel.height), line, body);

        if (!canMove && conversation == null && !showInventory && !qteActive)
        {
            var button = new Rect(panel.xMax - size * 2.35f, panel.yMax + size * 0.18f, size * 2.35f, size * 0.8f);
            if (GUI.Button(button, Translate("Next", "Дальше", "Далі"), largeButton))
                advanceSpeechFrame = Time.frameCount;
        }
    }

    private void DrawChoices()
    {
        int count = conversation.GetNumEnabledOptions();
        if (count == 0)
            return;

        float width = Mathf.Min(safe.width * 0.78f, size * 11f);
        float row = size * 1.02f;
        float height = Mathf.Min(row * count + size * 0.2f, safe.height * 0.42f);
        var panel = new Rect(safe.center.x - width / 2f, safe.yMax - height - size * 0.5f, width, height);
        DrawBackground(panel);
        var viewport = new Rect(panel.x + size * 0.14f, panel.y + size * 0.1f, panel.width - size * 0.28f, panel.height - size * 0.2f);
        float contentWidth = viewport.width - (row * count > viewport.height ? size * 0.28f : 0);
        choiceScroll = GUI.BeginScrollView(viewport, choiceScroll, new Rect(0, 0, contentWidth, row * count));
        int selected = -1;
        for (int index = 0; index < count; index++)
        {
            if (GUI.Button(new Rect(0, row * index, contentWidth, row - size * 0.1f),
                conversation.GetOptionName(index), largeButton))
                selected = index;
        }
        GUI.EndScrollView();

        if (selected >= 0)
        {
            choiceScroll = Vector2.zero;
            conversation.RunOption(selected);
        }
    }

    private void DrawInventory()
    {
        var panel = CenterPanel(size * 8.2f, size * 5.3f);
        DrawBackground(panel);
        GUI.Label(new Rect(panel.x, panel.y, panel.width, size), Translate("Inventory", "Инвентарь", "Інвентар"), title);
        if (GUI.Button(new Rect(panel.xMax - size * 0.92f, panel.y + size * 0.15f, size * 0.75f, size * 0.74f),
            "×", largeButton))
        {
            showInventory = false;
            return;
        }

        var inventory = KickStarter.runtimeInventory;
        if (inventory == null || inventory.PlayerInvCollection == null)
            return;

        List<InvInstance> items = inventory.PlayerInvCollection.InvInstances;
        var viewport = new Rect(panel.x + size * 0.25f, panel.y + size * 1.14f, panel.width - size * 0.5f, panel.height - size * 1.4f);
        int count = 0;
        foreach (var item in items)
            if (InvInstance.IsValid(item))
                count++;

        if (count == 0)
        {
            GUI.Label(viewport, Translate("Empty", "Пусто", "Порожньо"), body);
            return;
        }

        float row = size * 0.85f;
        float width = viewport.width - (row * count > viewport.height ? size * 0.28f : 0);
        inventoryScroll = GUI.BeginScrollView(viewport, inventoryScroll, new Rect(0, 0, width, row * count));
        InvInstance selected = null;
        int index = 0;
        foreach (var item in items)
        {
            if (!InvInstance.IsValid(item))
                continue;

            string label = item.InvItem.GetLabel(Options.GetLanguage());
            if (item.Count > 1)
                label += " ×" + item.Count;
            if (item == inventory.SelectedInstance)
                label = "✓ " + label;

            var bounds = new Rect(0, index * row, width, row - size * 0.09f);
            if (GUI.Button(bounds, label, largeButton))
                selected = item;
            if (item.InvItem.tex != null)
                GUI.DrawTexture(new Rect(size * 0.18f, bounds.y + size * 0.08f, size * 0.55f, size * 0.55f),
                    item.InvItem.tex, ScaleMode.ScaleToFit);
            index++;
        }
        GUI.EndScrollView();

        if (selected != null)
        {
            if (selected == inventory.SelectedInstance)
                inventory.SetNull();
            else
                inventory.SelectItem(selected);
            showInventory = false;
        }
    }

    private void DrawControls()
    {
        DrawButtonMarker(actionRect, Translate("Use", "Действие", "Дія"), interactPressed);
        DrawButtonMarker(runRect, Translate("Run", "Бег", "Біг"), runFinger >= 0);
        DrawButtonMarker(inventoryRect, Translate("Inventory", "Инвентарь", "Інвентар"), false);
        DrawButtonMarker(pauseRect, Translate("Pause", "Пауза", "Пауза"), false);
        DrawButtonMarker(flashRect, Translate("Hints", "Подсказки", "Підказки"), flashPressed);

        Vector2 center = moveFinger < 0 ? moveRect.center : moveOrigin;
        GUI.DrawTexture(new Rect(center.x - size * 0.78f, center.y - size * 0.78f, size * 1.56f, size * 1.56f), ring);
        Vector2 thumb = center + new Vector2(movement.x, -movement.y) * (size * 0.63f);
        GUI.DrawTexture(new Rect(thumb.x - size * 0.31f, thumb.y - size * 0.31f, size * 0.62f, size * 0.62f), knob);
    }

    private void DrawButtonMarker(Rect rect, string text, bool pressed)
    {
        if (Event.current.type == EventType.Repaint)
            largeButton.Draw(rect, new GUIContent(text), false, pressed, false, false);
    }

    private Rect CenterPanel(float width, float height)
    {
        width = Mathf.Min(safe.width * 0.93f, width);
        height = Mathf.Min(safe.height * 0.86f, height);
        return new Rect(safe.center.x - width / 2f, safe.center.y - height / 2f, width, height);
    }

    private static void DrawBackground(Rect rect)
    {
        Color previous = GUI.color;
        GUI.color = new Color(0.025f, 0.035f, 0.045f, 0.94f);
        GUI.DrawTexture(rect, Texture2D.whiteTexture);
        GUI.color = previous;
    }

    private static Texture2D MakeCircle(Color fill)
    {
        const int resolution = 72;
        var tex = new Texture2D(resolution, resolution, TextureFormat.RGBA32, false);
        tex.wrapMode = TextureWrapMode.Clamp;
        var pixels = new Color[resolution * resolution];
        for (int y = 0; y < resolution; y++)
        for (int x = 0; x < resolution; x++)
        {
            float distance = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(36f, 36f));
            var color = distance > 32.5f ? Color.Lerp(fill, Color.white, 0.18f) : fill;
            color.a *= Mathf.Clamp01(35.7f - distance);
            pixels[y * resolution + x] = color;
        }
        tex.SetPixels(pixels);
        tex.Apply(false, true);
        return tex;
    }

    private static string Translate(string english, string russian, string ukrainian)
    {
        switch (PlayerPrefs.GetInt("Language", 0))
        {
            case 4: return russian;
            case 5: return ukrainian;
            default: return english;
        }
    }
}
