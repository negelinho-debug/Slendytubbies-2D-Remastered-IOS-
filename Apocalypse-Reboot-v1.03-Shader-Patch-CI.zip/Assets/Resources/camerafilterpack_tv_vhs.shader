Shader "CameraFilterPack/TV_VHS" {
	Properties {
		_MainTex ("Base (RGB)", 2D) = "white" {}
		_TimeX ("Time", Range(0, 1)) = 1
		_ScreenResolution ("_ScreenResolution", Vector) = (0,0,0,0)
	}
	
    SubShader
    {
        Cull Off
        ZWrite Off
        ZTest Always
        CGINCLUDE
        #include "UnityCG.cginc"
        sampler2D _MainTex;
        float4 _MainTex_TexelSize, _ColorRGB, _ScreenResolution;
        float _TimeX, _Greenness, _OnOff, _Vignette, _Vignette_Alpha, _Light, _Noise;
        float _Distortion, _Fade, _Brightness, _Contrast, _Saturation;
        float _Value, _Value2, _Value3, _Value4, _Amount, _Color_R, _Color_G, _Color_B;

        float hash(float2 p)
        {
            return frac(sin(dot(p, float2(12.9898, 78.233))) * 43758.5453);
        }
        half4 frag(v2f_img input) : SV_Target
        {
            float2 uv = input.uv;
            half4 original = tex2D(_MainTex, uv);
            
            float row = floor(uv.y * 180);
            float jitter = (hash(float2(row, floor(_TimeX * 16))) - .5)
                         * saturate(abs(_Value) + abs(_Value3)) * .015;
            half4 video = tex2D(_MainTex, saturate(uv + float2(jitter, 0)));
            float staticNoise = (hash(uv * 2048 + _TimeX) - .5) * saturate(_Value2 + _Value4) * .14;
            return half4(saturate(video.rgb * (.93 + .07 * sin(uv.y * 850)) + staticNoise), video.a);

        }
        ENDCG
        
        Pass
        {
            CGPROGRAM
            #pragma target 3.0
            #pragma vertex vert_img
            #pragma fragment frag
            ENDCG
        }

    }
}
