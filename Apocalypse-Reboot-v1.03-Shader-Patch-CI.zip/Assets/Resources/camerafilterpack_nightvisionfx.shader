Shader "CameraFilterPack/NightVisionFX" {
	Properties {
		_MainTex ("Base (RGB)", 2D) = "white" {}
	}
	
    SubShader
    {
        Cull Off
        ZWrite Off
        ZTest Always
        CGINCLUDE
        #include "UnityCG.cginc"
        sampler2D _MainTex;
        float4 _MainTex_TexelSize, _ColorRGB, _ScreenResolution;
        float _TimeX, _Greenness, _OnOff, _Vignette, _Vignette_Alpha, _Light, _Noise;
        float _Distortion, _Fade, _Brightness, _Contrast, _Saturation;
        float _Value, _Value2, _Value3, _Value4, _Amount, _Color_R, _Color_G, _Color_B;

        float hash(float2 p)
        {
            return frac(sin(dot(p, float2(12.9898, 78.233))) * 43758.5453);
        }
        half4 frag(v2f_img input) : SV_Target
        {
            float2 uv = input.uv;
            half4 original = tex2D(_MainTex, uv);
            
            float luminance = saturate(dot(original.rgb, float3(.299, .587, .114)));
            float vision = sqrt(luminance) * (1.2 + .3 * clamp(abs(_Greenness), .2, 2));
            float falloff = 1 - .35 * smoothstep(.18, .72, length(uv - .5));
            float grain = (hash(floor(uv * max(_ScreenResolution.xy, float2(1, 1)))
                              + floor(_TimeX * 30)) - .5) * .055;
            float3 tint = float3(.22, 1, .28);

            tint = max(tint + float3(_Color_R, _Color_G, _Color_B) * .3, .04);
            vision *= .75 + .4 * max(_Light, 0);
            float shade = lerp(1, falloff, saturate(_Vignette * _Vignette_Alpha));
            float3 night = saturate((vision + grain * saturate(_Noise)) * tint * shade);
            return half4(lerp(night, original.rgb, saturate(_OnOff)), original.a);

        }
        ENDCG
        
        Pass
        {
            CGPROGRAM
            #pragma target 3.0
            #pragma vertex vert_img
            #pragma fragment frag
            ENDCG
        }

    }
}
