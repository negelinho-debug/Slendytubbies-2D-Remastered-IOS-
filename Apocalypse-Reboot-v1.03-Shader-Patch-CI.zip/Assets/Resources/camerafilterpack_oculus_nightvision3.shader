Shader "CameraFilterPack/Oculus_NightVision3" {
	Properties {
		_MainTex ("Base (RGB)", 2D) = "white" {}
		_TimeX ("Time", Range(0, 1)) = 1
		_Distortion ("_Distortion", Range(0, 1)) = 0.3
		_ScreenResolution ("_ScreenResolution", Vector) = (0,0,0,0)
		_BinocularSize ("_BinocularSize", Range(0, 1)) = 0.5
		_BinocularDistance ("_BinocularDistance", Range(0, 1)) = 0.5
		_Greenness ("_Greenness", Range(0, 1)) = 0.4
	}
	
    SubShader
    {
        Cull Off
        ZWrite Off
        ZTest Always
        CGINCLUDE
        #include "UnityCG.cginc"
        sampler2D _MainTex;
        float4 _MainTex_TexelSize, _ColorRGB, _ScreenResolution;
        float _TimeX, _Greenness, _OnOff, _Vignette, _Vignette_Alpha, _Light, _Noise;
        float _Distortion, _Fade, _Brightness, _Contrast, _Saturation;
        float _Value, _Value2, _Value3, _Value4, _Amount, _Color_R, _Color_G, _Color_B;

        float hash(float2 p)
        {
            return frac(sin(dot(p, float2(12.9898, 78.233))) * 43758.5453);
        }
        half4 frag(v2f_img input) : SV_Target
        {
            float2 uv = input.uv;
            half4 original = tex2D(_MainTex, uv);
            
            float luminance = saturate(dot(original.rgb, float3(.299, .587, .114)));
            float vision = sqrt(luminance) * (1.2 + .3 * clamp(abs(_Greenness), .2, 2));
            float falloff = 1 - .35 * smoothstep(.18, .72, length(uv - .5));
            float grain = (hash(floor(uv * max(_ScreenResolution.xy, float2(1, 1)))
                              + floor(_TimeX * 30)) - .5) * .055;
            float3 tint = float3(.22, 1, .28);
return half4(saturate((vision + grain) * tint * falloff), original.a);
        }
        ENDCG
        
        Pass
        {
            CGPROGRAM
            #pragma target 3.0
            #pragma vertex vert_img
            #pragma fragment frag
            ENDCG
        }

    }
}
