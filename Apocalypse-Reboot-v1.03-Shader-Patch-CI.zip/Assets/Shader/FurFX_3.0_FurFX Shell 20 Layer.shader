Shader "FurFX/3.0/FurFX Shell 20 Layer" {
	Properties {
		_Color ("Color (RGB)", Vector) = (1,1,1,1)
		_SpecColor ("Specular Material Color (RGB)", Vector) = (1,1,1,1)
		_BonusAmbient ("Bonus Ambient", Vector) = (0,0,0,1)
		_Shininess ("Shininess", Range(0.01, 10)) = 8
		_Gloss ("Gloss", Range(0, 3)) = 1
		_RimColor ("Rim Color", Vector) = (0,0,0,0)
		_RimPower ("Rim Power", Range(0.5, 8)) = 4
		_FurLength ("Fur Length", Range(0.0002, 0.2)) = 0.05
		_MainTex ("Base (RGB) Mask(A)", 2D) = "white" {}
		_BumpMap ("Normalmap", 2D) = "bump" {}
		_NoiseTex ("Noise (RGB)", 2D) = "white" {}
		_Cube ("Reflection Map", Cube) = "" {}
		_ReflColor ("Reflection Color (RGB)", Vector) = (1,1,1,1)
		_Reflection ("Reflection Power", Range(0, 1)) = 0
		_ReflMinLevel ("Reflection Minimal Length", Range(0, 1)) = 0
		_Cutoff ("Alpha Cutoff", Range(0, 0.5)) = 0.2
		_HairHardness ("Fur Hardness", Range(0.1, 1)) = 1
		_HairThinness ("Fur Thinness", Range(0.01, 5)) = 2
		_HairShading ("Fur Shading", Range(0, 0.5)) = 0.25
		_HairColoring ("Fur Coloring", Range(0, 1)) = 0.1
		_SkinAlpha ("Mask Alpha Factor", Range(0, 1)) = 0.5
		_ForceGlobal ("Force Global", Vector) = (0,0,0,0)
		_ForceLocal ("Force Local", Vector) = (0,0,0,0)
	}
	
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        Cull Off
        CGPROGRAM
        #pragma target 3.0
        #pragma surface surf Lambert addshadow
        sampler2D _MainTex, _BumpMap;
        fixed4 _Color;
        struct Input { float2 uv_MainTex; float2 uv_BumpMap; };
        void surf(Input input, inout SurfaceOutput output)
        {
            fixed4 c = tex2D(_MainTex, input.uv_MainTex) * _Color;
            output.Albedo = c.rgb;
            output.Alpha = c.a;
            output.Normal = UnpackNormal(tex2D(_BumpMap, input.uv_BumpMap));
        }
        ENDCG
    }
    Fallback "Diffuse"
}
