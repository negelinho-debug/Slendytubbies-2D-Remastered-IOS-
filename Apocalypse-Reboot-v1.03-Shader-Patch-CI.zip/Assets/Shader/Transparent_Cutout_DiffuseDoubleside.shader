Shader "Transparent/Cutout/DiffuseDoubleside" {
	Properties {
        _BumpMap ("Normal Map", 2D) = "bump" {}
		_Color ("Main Color", Vector) = (1,1,1,1)
		_MainTex ("Base (RGB) Trans (A)", 2D) = "white" {}
		_Cutoff ("Alpha cutoff", Range(0, 1)) = 0.5
	}
	
    SubShader
    {
        Tags { "Queue"="AlphaTest" "RenderType"="TransparentCutout" }
        Cull Off
        CGPROGRAM
        #pragma target 3.0
        #pragma surface surf Lambert alphatest:_Cutoff addshadow
        sampler2D _MainTex, _BumpMap;
        fixed4 _Color;
        struct Input { float2 uv_MainTex; float2 uv_BumpMap; };
        void surf(Input input, inout SurfaceOutput output)
        {
            fixed4 c = tex2D(_MainTex, input.uv_MainTex) * _Color;
            output.Albedo = c.rgb;
            output.Alpha = c.a;
            output.Normal = UnpackNormal(tex2D(_BumpMap, input.uv_BumpMap));
        }
        ENDCG
    }
    Fallback "Diffuse"
}
