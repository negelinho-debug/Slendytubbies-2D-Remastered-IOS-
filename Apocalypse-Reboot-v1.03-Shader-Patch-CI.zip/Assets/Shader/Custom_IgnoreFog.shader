Shader "Custom/IgnoreFog" {
	Properties {
        _BumpMap ("Normal Map", 2D) = "bump" {}
		_MainTex ("Texture", 2D) = "white" {}
		_Color ("Color", Vector) = (1,1,1,1)
	}
	
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        Cull Back
        CGPROGRAM
        #pragma target 3.0
        #pragma surface surf Lambert addshadow
        sampler2D _MainTex, _BumpMap;
        fixed4 _Color;
        struct Input { float2 uv_MainTex; float2 uv_BumpMap; };
        void surf(Input input, inout SurfaceOutput output)
        {
            fixed4 c = tex2D(_MainTex, input.uv_MainTex) * _Color;
            output.Albedo = c.rgb;
            output.Alpha = c.a;
            output.Normal = UnpackNormal(tex2D(_BumpMap, input.uv_BumpMap));
            output.Emission = c.rgb;
            output.Albedo = 0;
        }
        ENDCG
    }
    Fallback "Diffuse"
}
