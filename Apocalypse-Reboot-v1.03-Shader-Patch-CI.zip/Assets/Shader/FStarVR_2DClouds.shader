Shader "FStarVR/2DClouds" {
	Properties {
        _BumpMap ("Normal Map", 2D) = "bump" {}
        _Color ("Color", Color) = (1,1,1,1)
        _MainTex ("Texture", 2D) = "white" {}
		_CloudColor ("Color", Vector) = (1,1,1,0.5)
		_Density ("Density", Range(0, 2)) = 0.2
		_Speed ("Speed", Range(-1, 1)) = 0.1
		_ScatterMap0 ("Scatter Map 1", 2D) = "white" {}
		_ScatterMap1 ("Scatter Map 2", 2D) = "white" {}
		_DensityMap ("Density Map", 2D) = "white" {}
		_TextureMap ("Texture Map", 2D) = "white" {}
	}
	
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        Cull Back
        CGPROGRAM
        #pragma target 3.0
        #pragma surface surf Lambert addshadow
        sampler2D _MainTex, _BumpMap;
        fixed4 _Color;
        struct Input { float2 uv_MainTex; float2 uv_BumpMap; };
        void surf(Input input, inout SurfaceOutput output)
        {
            fixed4 c = tex2D(_MainTex, input.uv_MainTex + _Time.y * float2(.008, 0)) * _Color;
            output.Albedo = c.rgb;
            output.Alpha = c.a;
            output.Normal = UnpackNormal(tex2D(_BumpMap, input.uv_BumpMap));
            output.Emission = c.rgb;
            output.Albedo = 0;
        }
        ENDCG
    }
    Fallback "Diffuse"
}
