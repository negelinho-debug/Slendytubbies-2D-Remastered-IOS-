"""Move AssetRipper's scene-owned Adventure Creator actions into their original scenes."""
from collections import defaultdict
from pathlib import Path
import re
import sys

GUID = re.compile(r"(?m)^guid: ([0-9a-f]{32})$")
PREF = re.compile(r"\{fileID: (-?\d+), guid: ([0-9a-f]{32}), type: (\d+)\}")
DOC = re.compile(r"(?m)^--- !u!(\d+) &(-?\d+)[^\n]*")
LOCAL_PREF = re.compile(r"\{fileID: (-?\d+)\}")
DEPENDENCY_TYPES = {".asset", ".prefab", ".playable", ".controller", ".anim", ".mat", ".mixer", ".unity"}

def asset_guid(path):
    meta = path.with_name(path.name + ".meta").read_text(encoding="utf-8-sig")
    return GUID.search(meta)[1]

def read_scene_yaml(path):
    raw = path.read_bytes()
    return raw.decode("utf-8-sig") if raw.startswith((b"%YAML", b"\xef\xbb\xbf%YAML")) else ""

def repair(project):
    assets = project / "Assets"
    scenes = {asset_guid(path): path for path in sorted(assets.rglob("*.unity"))}
    if len(scenes) != 11:
        raise ValueError(f"Expected 11 original Apocalypse 1.03 scenes, found {len(scenes)}")

    scene_text = {guid: read_scene_yaml(path) for guid, path in scenes.items()}
    scene_ids = {guid: {int(m[2]) for m in DOC.finditer(source)}
                 for guid, source in scene_text.items()}
    actions = {}
    for path in sorted((assets / "MonoBehaviour").glob("*.asset")):
        source = read_scene_yaml(path)
        if "  isAssetFile: 0\n" not in source or "  m_GameObject: {fileID: 0}\n" not in source:
            continue
        docs = list(DOC.finditer(source))
        if len(docs) != 1 or docs[0][1] != "114":
            raise ValueError(f"Unexpected action asset layout: {path}")
        actions[asset_guid(path)] = (path, int(docs[0][2]), source[docs[0].end():])

    if not actions:
        raise ValueError("No exported scene actions were found")

    owner = {}
    for scene, source in scene_text.items():
        pending = [guid for _, guid, _ in PREF.findall(source) if guid in actions]
        while pending:
            action = pending.pop()
            if action in owner:
                if owner[action] != scene:
                    raise ValueError(f"Action is used by two scenes: {actions[action][0]}")
                continue
            owner[action] = scene
            pending.extend(guid for _, guid, _ in PREF.findall(actions[action][2]) if guid in actions)

    if set(owner) != set(actions):
        raise ValueError(f"{len(set(actions) - set(owner))} scene actions have no owner")

    action_paths = {item[0] for item in actions.values()}
    scene_paths = set(scenes.values())
    for path in assets.rglob("*"):
        if path.suffix not in DEPENDENCY_TYPES or path in action_paths or path in scene_paths:
            continue
        for file_id, guid, _ in PREF.findall(read_scene_yaml(path)):
            if guid in actions or (guid in scenes and file_id != "102900000"):
                raise ValueError(f"Outside asset points at a scene-local object: {path}")

    assigned = {}
    for scene in scenes:
        next_id = max(1_000_000_000, max(scene_ids[scene], default=0)) + 1
        for action in sorted(guid for guid, scope in owner.items() if scope == scene):
            assigned[action] = next_id
            next_id += 1

    fixed_links = 0
    documents = defaultdict(list)
    for action, (path, original_id, body) in actions.items():
        scene = owner[action]

        def move_local(match):
            file_id = int(match[1])
            if file_id == 0:
                return match[0]
            if file_id != original_id:
                raise ValueError(f"Unexpected local pointer in action {path}: {file_id}")
            return f"{{fileID: {assigned[action]}}}"

        def move_external(match):
            nonlocal fixed_links
            file_id, guid = int(match[1]), match[2]
            if guid in scenes and file_id != 102900000:
                if guid != scene or file_id not in scene_ids[scene]:
                    raise ValueError(f"Action points to a missing object or foreign scene: {path}")
                fixed_links += 1
                return f"{{fileID: {file_id}}}"
            if guid in actions:
                if owner[guid] != scene or actions[guid][1] != file_id:
                    raise ValueError(f"Action points to a missing or foreign action: {path}")
                return f"{{fileID: {assigned[guid]}}}"
            return match[0]

        body = PREF.sub(move_external, LOCAL_PREF.sub(move_local, body))
        documents[scene].append(f"--- !u!114 &{assigned[action]}{body.rstrip()}\n")

    updated = {}
    for scene, source in scene_text.items():
        if not documents[scene]:
            continue

        def move_action_reference(match):
            file_id, guid = int(match[1]), match[2]
            if guid not in actions:
                return match[0]
            if owner[guid] != scene or actions[guid][1] != file_id:
                raise ValueError(f"Incorrect action reference in {scenes[scene]}")
            return f"{{fileID: {assigned[guid]}}}"

        updated[scenes[scene]] = PREF.sub(move_action_reference, source).rstrip() + "\n" + "".join(documents[scene])
        print(f"{scenes[scene].name}: embedded {len(documents[scene])} actions")

    if fixed_links == 0:
        raise ValueError("Expected exported references from actions to scene objects")
    for path, source in updated.items():
        path.write_text(source, encoding="utf-8")
    for path in action_paths:
        path.unlink()
        path.with_name(path.name + ".meta").unlink()
    print(f"Localized {fixed_links} references in {len(actions)} actions across {len(updated)} original scenes.")

if __name__ == "__main__":
    repair(Path(sys.argv[1]).resolve())
